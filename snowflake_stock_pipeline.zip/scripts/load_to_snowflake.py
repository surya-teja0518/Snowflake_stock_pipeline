import snowflake.connector
import os
from dotenv import load_dotenv

load_dotenv("configs/.env")

def load_to_snowflake():
    conn = snowflake.connector.connect(
        user=os.getenv("SNOWFLAKE_USER"),
        password=os.getenv("SNOWFLAKE_PASSWORD"),
        account=os.getenv("SNOWFLAKE_ACCOUNT"),
        warehouse=os.getenv("SNOWFLAKE_WAREHOUSE"),
        database=os.getenv("SNOWFLAKE_DATABASE"),
        schema=os.getenv("SNOWFLAKE_SCHEMA")
    )
    
    cursor = conn.cursor()
    file_path = "data/stocks.csv"
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS stocks.price_data (
            timestamp TIMESTAMP,
            symbol STRING,
            open FLOAT,
            high FLOAT,
            low FLOAT,
            close FLOAT,
            volume INT
        )
    """)

    with open(file_path, "r") as file:
        next(file)  # Skip header row
        for line in file:
            values = line.strip().split(",")
            cursor.execute(f"""
                INSERT INTO stocks.price_data VALUES ('{values[0]}', '{values[1]}', {values[2]}, {values[3]}, {values[4]}, {values[5]}, {values[6]})
            """)
    
    conn.commit()
    cursor.close()
    conn.close()
    print("Data loaded into Snowflake successfully!")

if __name__ == "__main__":
    load_to_snowflake()
