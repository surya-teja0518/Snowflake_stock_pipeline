import requests
import os

def fetch_stock_data():
    url = "https://www.alphavantage.co/query"
    params = {
        "function": "TIME_SERIES_INTRADAY",
        "symbol": "AAPL",
        "interval": "5min",
        "apikey": "your_api_key",
        "datatype": "csv"
    }
    response = requests.get(url)
    if response.status_code == 200:
        os.makedirs("data", exist_ok=True)
        file_path = "data/stocks.csv"
        with open(file_path, "wb") as f:
            f.write(response.content)
        print(f"Stock data saved to {file_path}")
    else:
        print("Failed to fetch stock data")

if __name__ == "__main__":
    fetch_stock_data()
